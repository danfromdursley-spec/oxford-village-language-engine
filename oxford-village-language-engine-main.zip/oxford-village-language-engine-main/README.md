# oxford-village-language-engine
An experimental linguistic engine that generates and classifies proto-roots using phonetic heuristics, semantic clustering, and minimal-substrate rules. Designed as an educational and research demonstration.
